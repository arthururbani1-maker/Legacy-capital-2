# Legacy Capital · Painel Patrimonial

PWA (Progressive Web App) de gestão patrimonial e financeira pessoal — imóveis, consórcios, leilões, investimentos, controle de renda, metas, projeções e relatórios. Funciona offline e pode ser instalado no celular ou desktop.

## Estrutura

```
.
├── index.html                 # redireciona para o dashboard
├── dashboard-patrimonio.html  # o app (single-file: HTML + CSS + JS inline)
├── manifest.json              # configuração do PWA (ícones, cores, nome)
├── service-worker.js          # cache offline-first
├── assets/icons/              # ícones do PWA (192, 512, maskable, apple-touch)
├── _headers / _redirects      # configuração de hosting (Netlify)
```

## Como rodar localmente

Por ser um PWA com service worker, precisa ser servido por HTTP (não abrir o arquivo direto). Na pasta do projeto:

```bash
python3 -m http.server 8080
```

Depois acesse `http://localhost:8080`.

## Deploy

Qualquer hosting de site estático serve (Netlify, Vercel, GitHub Pages). Para GitHub Pages: ative em *Settings → Pages → Branch: main → / (root)*.

## Dados

Todos os dados ficam no `localStorage` do navegador do usuário — nada é enviado a servidores. Exportação/importação em JSON disponível no próprio app.

## Tecnologia

Single-file PWA, sem build e sem dependências de pacote. Tema claro/escuro, totalmente responsivo (mobile-first).
